const audioPlayer = document.getElementById('audio-player');
const playPauseButton = document.getElementById('play-pause-btn');
const progressSlider = document.getElementById('progress');
const currentTimeDisplay = document.getElementById('current-time');
const totalTimeDisplay = document.getElementById('total-time');
const prevButton = document.getElementById('prev-btn');
const nextButton = document.getElementById('next-btn');

// Media files (no video files in this case)
const mediaFiles = [
  { title: 'Space Bound', artist: 'Eminem', src: 'Eminem - Space Bound (Official Video) (128kbps).mp3', type: 'audio', image: 'OIP (1).jpg' },
  { title: 'Stan', artist: 'Eminem', src: 'Stan.mp3', type: 'Audio', image: 'OIP (1).jpg' },
  { title: 'Till I Collapse', artist: 'Eminem', src: 'Till I Collapse.mp3', type: 'audio', image: 'OIP (1).jpg' },
  { title: ' Mockingbird', artist: 'Eminem', src: 'yt1s.com - Eminem  Mockingbird Official Music Video.mp3', type: 'audio', image: 'OIP (1).jpg' },
  { title: 'Heroes tonight', artist: 'Janji', src: 'yt1s.com - Janji  Heroes Tonight feat Johnning  JF  Music Video 4K_1080p.mp4', type: 'video' },
  { title: 'This time for Africa', artist: 'Shakira', src: 'yt1s.io - Shakira - Waka Waka (This Time for Africa) (The Official 2010 FIFA World Cup™ Song) (128 kbps).mp3', type: 'audio', image: 'OIP (1).jpg' }
];


let currentMediaIndex = 0;
let isPlaying = false;

// time duration
function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
}

//  media file
function loadMedia(index) {
  const currentMedia = mediaFiles[index];
  document.querySelector('.media-title').textContent = currentMedia.title;
  document.querySelector('.artist-name').textContent = currentMedia.artist;

  // Pause and reset the audio player
  audioPlayer.pause();
  audioPlayer.currentTime = 0;
  audioPlayer.src = currentMedia.src;
  audioPlayer.load();
  resetProgress();
}

// progress bar and time displays
function resetProgress() {
  progressSlider.value = 0;
  currentTimeDisplay.textContent = '00:00';
  totalTimeDisplay.textContent = '00:00';
}

// Play or pause audio
function togglePlayPause() {
  if (isPlaying) {
    audioPlayer.pause();
    playPauseButton.textContent = '▶';
  } else {
    audioPlayer.play();
    playPauseButton.textContent = '❚❚';
  }
  isPlaying = !isPlaying;
}

playPauseButton.addEventListener('click', togglePlayPause);

// Add event listener for the space bar
document.addEventListener('keydown', (event) => {
  if (event.code === 'Space') {
    event.preventDefault(); // Prevent scrolling when pressing space
    togglePlayPause();
  }else if (event.code === 'ArrowRight') {
    // Right arrow key for next song
    switchToNextSong();
  } else if (event.code === 'ArrowLeft') {
    // Left arrow key for previous song
    switchToPreviousSong();
  }
});

// Switch to the next song
function switchToNextSong() {
  currentMediaIndex = (currentMediaIndex + 1) % mediaFiles.length;
  loadMedia(currentMediaIndex);
  audioPlayer.play();
  isPlaying = true;
  playPauseButton.textContent = '❚❚';
}

// Switch to the previous song
function switchToPreviousSong() {
  currentMediaIndex = (currentMediaIndex - 1 + mediaFiles.length) % mediaFiles.length;
  loadMedia(currentMediaIndex);
  audioPlayer.play();
  isPlaying = true;
  playPauseButton.textContent = '❚❚';
}



// Update progress bar
audioPlayer.addEventListener('timeupdate', () => {
  const currentTime = audioPlayer.currentTime;
  const duration = audioPlayer.duration;
  progressSlider.value = (currentTime / duration) * 100;
  currentTimeDisplay.textContent = formatTime(currentTime);
  if (duration) {
    totalTimeDisplay.textContent = formatTime(duration);
  }
});

// Seek media
progressSlider.addEventListener('input', () => {
  audioPlayer.currentTime = (progressSlider.value / 100) * audioPlayer.duration;
});

// Play next song automatically when the current song ends
audioPlayer.addEventListener('ended', () => {
  currentMediaIndex = (currentMediaIndex + 1) % mediaFiles.length; // Loop back to the first song
  loadMedia(currentMediaIndex);
  audioPlayer.play();
  isPlaying = true;
  playPauseButton.textContent = '❚❚';
});

// Next and Previous Buttons
nextButton.addEventListener('click', () => {
  currentMediaIndex = (currentMediaIndex + 1) % mediaFiles.length;
  loadMedia(currentMediaIndex);
  isPlaying = true;
  playPauseButton.textContent = '❚❚';
  audioPlayer.play();
});

prevButton.addEventListener('click', () => {
  currentMediaIndex = (currentMediaIndex - 1 + mediaFiles.length) % mediaFiles.length;
  loadMedia(currentMediaIndex);
  isPlaying = true;
  playPauseButton.textContent = '❚❚';
  audioPlayer.play();
});

// Load the first media file
loadMedia(currentMediaIndex);

// Show/hide controls on hover
const mediaPlayerContainer = document.querySelector('.media-player');
mediaPlayerContainer.addEventListener('mouseenter', () => {
  document.querySelector('.controls').style.display = 'flex';
});
mediaPlayerContainer.addEventListener('mouseleave', () => {
  document.querySelector('.controls').style.display = 'none';
});
